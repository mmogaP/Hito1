Integrantes: Nucore

Mauricio Moraga
Andres Martinez
Joel Santana
Jaime Godoy